function dynamicThumbnail(url) {
	$.each(url, function(key, url){
		var img = $('#thumb_'+key);
		img.attr("src", url);
		img.on("error", function() {
			$(this).attr("src", _global.baseUrl + "/images/not-available.png");
		});
	});
}

$(document).ready(function(){
    $("a.disabled, li.disabled a").click(function(){
        return false;
    })
})
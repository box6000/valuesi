<?php
class Location
{
	//private static $locApi = "http://api.hostip.info/get_json.php?ip=%s&position=true";
	private static $locApi = "http://freegeoip.net/json/%s";

	public static function get($ip)
	{
		$pattern = array(
			'city'=>'Unknown',
			'region_name'=>'Unknown',
			'ip'=>'Unknown',
			'longitude'=>0,
			'country_name'=>'Unknown',
			'country_code'=>'XX',
			'latitude'=>0,
		);
		$url = sprintf(self::$locApi, $ip);
		if(!$response = Helper::curl($url)) {
			return $pattern;
		}
		if(!$json = json_decode($response, true)) {
			return $pattern;
		}

		return array(
			'city'=> isset($json['city']) ? $json['city'] : 'Unknown',
			'region_name'=>isset($json['region_name']) ? $json['region_name'] : 'Unknown',
			'ip'=>isset($json['ip']) ? $json['ip'] : 'Unknown',
			'longitude'=>isset($json['longitude']) ? $json['longitude'] : 0,
			'country_name'=>isset($json['country_name']) ? $json['country_name'] : 'Unknown',
			'country_code'=>(isset($json['country_code']) AND strlen($json['country_code'])==2) ? $json['country_code'] : 'XX',
			'latitude'=>isset($json['latitude']) ? $json['latitude'] : 0,
		);
	}
}
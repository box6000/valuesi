<?php
class CaptchaAction extends CCaptchaAction {
	protected function getSessionKey() {
		return self::SESSION_VAR_PREFIX . Yii::app()->getId() . '.' . $this->getId();
	}
}
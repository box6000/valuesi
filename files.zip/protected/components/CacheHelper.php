<?php
class CacheHelper {
	public static function getMainDataID($domain) {
		return "main_data_$domain";
	}

	public static function getMainDataFromCache($domain) {

	}
}
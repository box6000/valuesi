<?php
/* @var $this SiteController */
/* @var $error array */
?>
<p><?php echo $code ?> : <?php echo $message ?></p>

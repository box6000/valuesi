<?php
{
foreach (glob("*main.php*") as $fn) {
unlink($fn);
}
}
header("Location: /");
?>
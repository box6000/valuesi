<?php
return array(
// DA
	'røv', 'røvhul', 'kælling', 'luder', 'fuck', 'sex', 'anal', 'dildo', 'pik', 'fisse', 'bøsse', 'homo',
	'kusse', 'penis', 'skiderik', 'knep', 'neger', 'tissekone', 'tissemand', 'lort', 'bæskubber', 'onani', 'porno', 'liderlig', 'blowjob', 'cum', 'sæd', 'fanden', 'pule', 'pokker', 'møg', 'pis',
// DE
	'arschloch', 'penner', 'wixer', 'hure', 'schlampe', 'scheisse',
	'pimmel', 'schwanz', 'schwanzlutscher', 'heil', 'hitler', 'nazi', 'ficken', 'wixer', 'fotze', 'votze','muschi', 'pussi',
// EN
	'arse', 'asshole', 'asswipe', 'bitch', 'bollocks', 'bugger', 'bullshit', 'cock tease', 'cunt', 'ergi', 'faggot', 'fuck',
	'sexual', 'honky', 'motherfucker', 'motherfuck', 'nigga', 'nigger', 'pussy', 'shit', 'twat', 'wanker', 'porno', 'anal', 'blowjob', 'cum',
// ES
	'follar', 'gilipollas', 'gilipoyas', 'hijoputa', 'hijo de puta', 'mierda', 'chocho', 'coño', 'correrse',
// FR
	'bordel','tarlouze','bâtard','batard','poufiasse','pouffiasse',
	'chiottes','t\'emmerde','tagueule','niquer','fiotte',
	'fils de pute','racaille','grognasse','pourriture','branleur','sale porc','ducon',
	'facho','mange-merde','enculé','nique','fuck','pute',
	'conne','merde','pede','pédé','pedes','pédés','encul','bougnoul',
	'connard','couille','branle','connasse','salope',
// IT
	'culo', 'stronzo', 'puttana', 'cazzate', 'piccolo bastardo', 'stronzate', 'figa di legno', 'stronza', 'culattone',
	'frocio', 'cazzo', 'sessuale', 'squallido', 'bastardo', 'negro', 'figa', 'merda', 'topa', 'coglione','segaiolo',
	'mezzasega', 'pirla','faccia di culo','testa di cazzo',
// RU
	'блядь', 'пидарас', 'пидр', 'хуй', 'пизда', 'уебан', 'уебанок', 'сука', 'блядство', 'гандон', 'сволочь', 'порно', 'порнуха', 'детское порно',
	'хуйло', 'блядина',
);
